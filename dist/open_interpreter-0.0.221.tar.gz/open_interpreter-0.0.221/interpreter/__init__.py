from .interpreter import Interpreter
import sys

# I'm sorry for my wrongs I have just begun
sys.modules["interpreter"] = Interpreter()