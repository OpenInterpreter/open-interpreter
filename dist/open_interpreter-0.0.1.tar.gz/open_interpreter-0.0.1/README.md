# open-interpreter
Lightweight interpreter that lets GPT-4 execute code locally.
